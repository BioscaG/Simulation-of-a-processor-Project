var searchData=
[
  ['leer_111',['leer',['../classArea__espera.html#a2f17732bd5c8a25c4fc43d45ad05f12f',1,'Area_espera::leer()'],['../classCluster.html#a482d879edb37f72e49c13e9c3e6c4320',1,'Cluster::leer()'],['../classProcesador.html#ae727a861bfcf316ccf52596b82fb18df',1,'Procesador::leer()'],['../classProceso.html#ad133f53bba77755f779ef63b6e529cdb',1,'Proceso::leer()']]]
];

var searchData=
[
  ['map_5fid_5fpos_124',['map_id_pos',['../classProcesador.html#adbead06dfa053feca87d365859e66aac',1,'Procesador']]],
  ['map_5fpos_5fproc_125',['map_pos_proc',['../classProcesador.html#a1912d047397c844c0d2d639cb008d220',1,'Procesador']]],
  ['map_5fprioridades_126',['map_prioridades',['../classArea__espera.html#aae3fff8f4e48cf933c2ef8583162d2fa',1,'Area_espera']]],
  ['map_5fprocesadores_127',['map_procesadores',['../classCluster.html#a1d04edf590b55b9cebb404c7622a5ff6',1,'Cluster']]],
  ['map_5ftam_5fpos_128',['map_tam_pos',['../classProcesador.html#a203cfe3cbf716f68f635c59c422d08b9',1,'Procesador']]],
  ['max_5fhueco_129',['max_hueco',['../classCluster.html#ae13156614b1fc0a70458b4b8d75342ea',1,'Cluster']]],
  ['mem_5fdisp_130',['mem_disp',['../classProcesador.html#a9880850a9c5946c9742e8a1f6a2628e4',1,'Procesador']]],
  ['mem_5ftotal_131',['mem_total',['../classProcesador.html#ad402509a08a7200bfe2d6088426e3fe5',1,'Procesador']]],
  ['memoria_132',['memoria',['../classProceso.html#ac37ccb93a804abd4b829ac7d4ad828bd',1,'Proceso']]]
];

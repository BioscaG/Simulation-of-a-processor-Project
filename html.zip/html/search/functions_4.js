var searchData=
[
  ['hueco_5fajustado_104',['hueco_ajustado',['../classProcesador.html#a3879ce52bc66e392acf273378abe1ed8',1,'Procesador']]]
];

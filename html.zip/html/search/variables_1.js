var searchData=
[
  ['id_5fprocesadores_120',['id_procesadores',['../classCluster.html#acfeafca3217def972ec31fd3cf3eb210',1,'Cluster']]],
  ['id_5fvacia_121',['ID_VACIA',['../classProceso.html#ae21d503017398889e7b0383476b108dc',1,'Proceso']]],
  ['identificador_122',['identificador',['../classProcesador.html#ac9edc7bbfe8bc9f673e8b1517232c84b',1,'Procesador::identificador()'],['../classProceso.html#a3418ac65a7c31135ed436bb38add64dc',1,'Proceso::identificador()']]]
];

var searchData=
[
  ['rechazados_60',['rechazados',['../classPrioridad.html#a65a0d943a980d29aedab2b7700a6ae7a',1,'Prioridad']]]
];

var searchData=
[
  ['alta_5fprioridad_82',['alta_prioridad',['../classArea__espera.html#a75f3c62722c06a0d93f839c1a3bed899',1,'Area_espera']]],
  ['alta_5fproceso_5fespera_83',['alta_proceso_espera',['../classArea__espera.html#a1d01a288d2bc1b08c1151092009569e0',1,'Area_espera']]],
  ['alta_5fproceso_5fprocesador_84',['alta_proceso_procesador',['../classCluster.html#a5e8b4e75eb9c4d4b71436416ec12c566',1,'Cluster']]],
  ['area_5fespera_85',['Area_espera',['../classArea__espera.html#a03fae0938ad34fe4e0ea6e0d0b0852b8',1,'Area_espera']]],
  ['aux_5fmejor_5fprocesador_86',['aux_mejor_procesador',['../classCluster.html#abf9fa5061ba7570480235a98a7eb86c6',1,'Cluster']]],
  ['avanzar_5ftiempo_87',['avanzar_tiempo',['../classCluster.html#ab56c23130c58c354ab095dfc5a7ce708',1,'Cluster::avanzar_tiempo()'],['../classProcesador.html#a0a134b52f16de92175316b19b9f39ba3',1,'Procesador::avanzar_tiempo()'],['../classProceso.html#a6a24c1ce42727cb2efb6e1a88549a574',1,'Proceso::avanzar_tiempo()']]],
  ['añadir_5fmejor_5fprocesador_88',['añadir_mejor_procesador',['../classCluster.html#aa033ae29380c2844f39881bae61bea6f',1,'Cluster']]],
  ['añadir_5fproceso_89',['añadir_proceso',['../classPrioridad.html#a240d7b0163e2514c15136523ffc853df',1,'Prioridad::añadir_proceso()'],['../classProcesador.html#a54d6880ab06153b25b8a5cd67e7b2eeb',1,'Procesador::añadir_proceso()']]]
];

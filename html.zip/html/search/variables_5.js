var searchData=
[
  ['set_5fprocesos_134',['set_procesos',['../classPrioridad.html#a19202537c9cf787442318364d65526ba',1,'Prioridad']]]
];

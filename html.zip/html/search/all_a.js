var searchData=
[
  ['set_5fprocesos_61',['set_procesos',['../classPrioridad.html#a19202537c9cf787442318364d65526ba',1,'Prioridad']]],
  ['simulación_20del_20rendimiento_20de_20procesadores_20interconectados_62',['Simulación del rendimiento de procesadores interconectados',['../index.html',1,'']]],
  ['sustituir_5farbol_63',['sustituir_arbol',['../classCluster.html#aceb41a14e27d9e5807c1eff77eaf7802',1,'Cluster']]]
];

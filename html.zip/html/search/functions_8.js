var searchData=
[
  ['prioridad_114',['Prioridad',['../classPrioridad.html#a239123296380077ef6959111bf599a90',1,'Prioridad']]],
  ['procesador_115',['Procesador',['../classProcesador.html#aacfa2a06c7d44636ecfb0338bebbfa8b',1,'Procesador']]],
  ['proceso_116',['Proceso',['../classProceso.html#a632f57d6ec48e76c80fbeb7734c1148c',1,'Proceso']]]
];

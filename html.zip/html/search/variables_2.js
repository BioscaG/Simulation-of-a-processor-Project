var searchData=
[
  ['lista_5fprocesos_123',['lista_procesos',['../classPrioridad.html#a7ac59247414fdb2cbffdece55b315f5e',1,'Prioridad']]]
];

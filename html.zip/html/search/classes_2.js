var searchData=
[
  ['prioridad_68',['Prioridad',['../classPrioridad.html',1,'']]],
  ['procesador_69',['Procesador',['../classProcesador.html',1,'']]],
  ['proceso_70',['Proceso',['../classProceso.html',1,'']]]
];

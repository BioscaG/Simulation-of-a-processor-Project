var searchData=
[
  ['vacio_118',['vacio',['../classPrioridad.html#aff9ddea700239e92ff3080f88764e4ae',1,'Prioridad::vacio()'],['../classProcesador.html#aa0cc3905c36dac0d66b2c078d4950eab',1,'Procesador::vacio()']]]
];

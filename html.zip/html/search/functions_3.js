var searchData=
[
  ['eliminar_5fproceso_101',['eliminar_proceso',['../classProcesador.html#a693a7a8f8de16dc55fcb636d74deab81',1,'Procesador']]],
  ['enviar_5fprocesos_5fcluster_102',['enviar_procesos_cluster',['../classArea__espera.html#acc1cf334e6d6e7c6d05a41474b4fe6d4',1,'Area_espera::enviar_procesos_cluster()'],['../classPrioridad.html#ae1c24435b94ef560bdbe50adc332d3bb',1,'Prioridad::enviar_procesos_cluster()']]],
  ['existe_5fproceso_103',['existe_proceso',['../classProcesador.html#ad9aefffa2a047a7fea75adb4ac7fd564',1,'Procesador']]]
];

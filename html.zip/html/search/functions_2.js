var searchData=
[
  ['cluster_92',['Cluster',['../classCluster.html#aee7feb1d599d4c8fda6c3ee83e86ba81',1,'Cluster']]],
  ['compactar_5fmemoria_5fcluster_93',['compactar_memoria_cluster',['../classCluster.html#a7b9ae511df4a6465f4e191df6564fd77',1,'Cluster']]],
  ['compactar_5fmemoria_5fprocesador_94',['compactar_memoria_procesador',['../classCluster.html#afdb2518f44bb07c6b7b672a5e8a52e43',1,'Cluster::compactar_memoria_procesador()'],['../classProcesador.html#a6c5d44f2b2e9aee6553a77d3056626f0',1,'Procesador::compactar_memoria_procesador()']]],
  ['construir_95',['construir',['../classCluster.html#a12029aac95230af99ad7f8349d77f2ff',1,'Cluster']]],
  ['consultar_5fid_96',['consultar_id',['../classProcesador.html#a3caaa26dfe5132fb7fc6b58f28c00343',1,'Procesador']]],
  ['consultar_5fidentificador_97',['consultar_identificador',['../classProceso.html#ae9cacc33b9e2909af8570790d10c8cd0',1,'Proceso']]],
  ['consultar_5fmemoria_98',['consultar_memoria',['../classProceso.html#a55976a19b8d909276c62e8be10036df5',1,'Proceso']]],
  ['consultar_5fmemoria_5fdisp_99',['consultar_memoria_disp',['../classProcesador.html#a016a2b73e391cedf2fe5d713d56a39f9',1,'Procesador']]],
  ['consultar_5ftiempo_100',['consultar_tiempo',['../classProceso.html#a4816bee1b97d41126160494109f84c42',1,'Proceso']]]
];

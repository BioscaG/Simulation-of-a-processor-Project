var searchData=
[
  ['baja_5fprioridad_11',['baja_prioridad',['../classArea__espera.html#a1627c35c708a0c05115a9ea086ddef0e',1,'Area_espera']]],
  ['baja_5fproceso_5fprocesador_12',['baja_proceso_procesador',['../classCluster.html#adcd863a8af0b5cdb130f42458bf3a745',1,'Cluster']]]
];
